import java.util.Scanner;

public class HealthCalculator {
    public void calculate() {
        Scanner ob = new Scanner(System.in);

        // Getting user input
        System.out.println("Enter your weight in kilograms:");
        double weight = ob.nextDouble();

        System.out.println("Enter your height in centimeters:");
        double height = ob.nextDouble();

        System.out.println("Enter your age in years:");
        int age = ob.nextInt();

        System.out.println("Enter your gender (M for male, F for female):");
        char gender = ob.next().toUpperCase().charAt(0);

        // Calculate BMI
        double heightInMeters = height / 100.0; // Convert height to meters
        double bmi = weight / (heightInMeters * heightInMeters);
        System.out.printf("Your BMI is: %.2f\n", bmi);

        // Calculate BMR
        double bmr;
        if (gender == 'M') {
            bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5;
        } else if (gender == 'F') {
            bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161;
        } else {
            System.out.println("Invalid gender entered!");
            return;
        }
        System.out.printf("Your BMR is: %.2f calories/day\n", bmr);
    }
}