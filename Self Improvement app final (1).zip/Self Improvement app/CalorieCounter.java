import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

// Base class for all features in my code, will make it easy to call later in MainApp.java
abstract class SelfImprovementApp {
    public abstract void initialize();
    public abstract void executeFeature();
}

// Feature: Calorie Tracker
class CalorieCounter extends SelfImprovementApp {
    private int totalCalories;          // Total calories consumed
    private double maintenanceCalories; // Maintenance calories for the user
    private Scanner scanner;            // Scanner for user input
    private Map<String, Double> foodDatabase; // Food item database (calories per gram or ml)

    public CalorieCounter() {
        totalCalories = 0;
        scanner = new Scanner(System.in);
        foodDatabase = new HashMap<>();
    }

    @Override
    public void initialize() {
        // Add sample food items to the database (calories per gram or ml)
        foodDatabase.put("bread", 2.5);       // Here I am storing calories in 1 gram or 1 ml of each food
        foodDatabase.put("pasta", 1.31);     
        foodDatabase.put("chicken", 2.39);   
        foodDatabase.put("milk", 0.62);      
        foodDatabase.put("rice", 1.3);       
        foodDatabase.put("egg", 1.55);       
        foodDatabase.put("apple", 0.52);     
        foodDatabase.put("banana", 0.89);    
        foodDatabase.put("potato", 0.77);    
        foodDatabase.put("carrot", 0.41);    

        System.out.println("Welcome to the Calorie Tracker!");
        System.out.println("Let's calculate your maintenance calories first.");
        calculateMaintenanceCalories();
    }

    @Override
    public void executeFeature() {
        boolean running = true;

        while (running) {
            System.out.println("\nWhat would you like to do?");
            System.out.println("1. Add calories from food");
            System.out.println("2. View total calories");
            System.out.println("3. Exit");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addCaloriesFromFood();
                    break;
                case 2:
                    viewTotalCalories();
                    break;
                case 3:
                    running = false;
                    System.out.println("Exiting Calorie Tracker. Stay healthy!");
                    break;
                default:
                    System.out.println("Invalid option, please try again.");
            }
        }
    }

    // Calculate maintenance calories
    private void calculateMaintenanceCalories() {
        System.out.print("Enter your height in cm: ");
        double height = scanner.nextDouble();

        System.out.print("Enter your weight in kg: ");
        double weight = scanner.nextDouble();

        System.out.print("Enter your age in years: ");
        int age = scanner.nextInt();

        System.out.println("Select your activity level:");
        System.out.println("1. Sedentary (little or no exercise)");
        System.out.println("2. Lightly active (light exercise/sports 1-3 days a week)");
        System.out.println("3. Moderately active (moderate exercise/sports 3-5 days a week)");
        System.out.println("4. Very active (hard exercise/sports 6-7 days a week)");
        System.out.println("5. Super active (very hard exercise, physical job, or training)");

        int activityLevel = scanner.nextInt();

        // Calculate BMR (Basal Metabolic Rate) using Mifflin-St Jeor Equation
        double bmr = 10 * weight + 6.25 * height - 5 * age + 5; // For men
        // If user is female, subtract 161: double bmr = 10 * weight + 6.25 * height - 5 * age - 161;

        // Adjust BMR based on activity level
        switch (activityLevel) {
            case 1: bmr *= 1.2; break;  // Sedentary
            case 2: bmr *= 1.375; break;  // Lightly active
            case 3: bmr *= 1.55; break;  // Moderately active
            case 4: bmr *= 1.725; break;  // Very active
            case 5: bmr *= 1.9; break;  // Super active
            default:
                System.out.println("Invalid activity level selected. Assuming sedentary.");
                bmr *= 1.2;
        }

        maintenanceCalories = bmr;
        System.out.printf("Your maintenance calories are approximately %.2f kcal/day.%n", maintenanceCalories);

        // Calculate caloric surplus/deficit for weight gain/loss
        System.out.printf("To lose weight, consume around %.2f kcal/day.%n", maintenanceCalories - 500);
        System.out.printf("To gain weight, consume around %.2f kcal/day.%n", maintenanceCalories + 500);
    }

    // Add calories based on food item
    private void addCaloriesFromFood() {
        System.out.println("Enter the name of the food item (e.g., 'bread', 'milk'):");
        scanner.nextLine();  // Consume the leftover newline
        String foodItem = scanner.nextLine().toLowerCase();

        if (foodDatabase.containsKey(foodItem)) {
            // If the food is in the database, ask for the quantity
            System.out.print("Enter the quantity in grams (for solids) or ml (for liquids): ");
            double quantity = scanner.nextDouble();
            double caloriesPerUnit = foodDatabase.get(foodItem);
            double caloriesToAdd = caloriesPerUnit * quantity;

            // Update total calories
            totalCalories += caloriesToAdd;
            System.out.println("Added " + caloriesToAdd + " calories from " + quantity + " units of " + foodItem);
        } else {
            // If the food is not in the database, let the user enter the calories manually
            System.out.print("Food item not found. Please enter the total number of calories: ");
            int calories = scanner.nextInt();
            totalCalories += calories;
            System.out.println("Added " + calories + " calories for " + foodItem);
        }
    }

    // View total calories consumed
    private void viewTotalCalories() {
        System.out.println("Total calories consumed today: " + totalCalories);
    }
}

