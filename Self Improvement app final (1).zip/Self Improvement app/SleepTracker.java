import java.util.Scanner;

public class SleepTracker {
    public void start() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your daily sleep goal in hours: ");
        double sleepGoal = scanner.nextDouble();

        System.out.print("Enter the number of hours you have slept so far: ");
        double hoursSlept = scanner.nextDouble();

        double remainingSleep = sleepGoal - hoursSlept;

        if (remainingSleep > 0) {
            System.out.println("\nYou need to sleep " + remainingSleep + " more hours to meet your daily goal.");
        } else {
            System.out.println("\nGreat job! You've already met your daily sleep goal.");
        }

        while (remainingSleep > 0) {
            System.out.print("\nEnter additional hours of sleep you just had: ");
            double additionalSleep = scanner.nextDouble();
            hoursSlept += additionalSleep;
            remainingSleep = sleepGoal - hoursSlept;

            if (remainingSleep > 0) {
                System.out.println("You still need to sleep " + remainingSleep + " more hours to meet your goal.");
            } else {
                System.out.println("Congratulations! You've met your daily sleep goal.");
            }
        }

        scanner.close();
    }
}
