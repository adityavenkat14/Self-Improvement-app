import java.util.Scanner;

public class MainApp 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        int option = 0;
        System.out.println("Welcome to the Self-Improvement App!");
    System.out.println("Your personal companion to track health, productivity, and wellness.");
    System.out.println("---------------------------------------------------------------\n");

        // Objects of all the features in this app
        CalorieCounter calorieCounter = new CalorieCounter();   // Calorie Counter-Zoheb part
        menu dailyPlanner = new menu();  // Daily Planner-Kshitij Part
        BrainTrainer brainTrainer = new BrainTrainer(); //BrainTrainer-Keshav part
        HealthCalculator health=new HealthCalculator(); //Venkat part
        SleepTracker sleep=new SleepTracker(); //Aman part 1
        WaterReminder water=new WaterReminder(); //Aman part 2
        WorkoutPlanner workout=new WorkoutPlanner(); //Falak part


        // Main menu loop
        while (option != 8) 
        {   // Adjusted for 7 features 
            System.out.println("Select an option: ");
            System.out.println("1. Calorie Counter");
            System.out.println("2. Daily Planner");
            System.out.println("3. Brain Trainer");
            System.out.println("4. Health Calculator");
            System.out.println("5. Water Reminder");
            System.out.println("6. Sleep Counter");
            System.out.println("7. Workout Planner");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            option = scanner.nextInt();

            switch (option) 
            {
                case 1:
                    // Calorie Counter feature
                    calorieCounter.initialize();
                    calorieCounter.executeFeature();
                    break;
                case 2:
                    // Call Daily Planner menu
                    dailyPlannerMenu(dailyPlanner);
                    break;
                case 3:
                    // Brain Trainer
                    brainTrainer.start();
                    break;
                case 4:
                    // HealthCalculator
                    health.calculate(); 
                    break;
                case 5:
                    // WaterReminder
                    water.start(); 
                break;
                case 6:
                    //Sleep Tracker
                    sleep.start(); 
                    break;
                case 7:
                    //Workout Planner
                    workout.executeFeature();
                    break;

                case 8:
                    //Exit
                    System.out.println("Exiting the app...");
                    break;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
        scanner.close();
    }

    // Menu function for Daily Planner- Kshitij Part implementation. This was only required for his code because he had 2 classes
    public static void dailyPlannerMenu(menu dailyPlanner) {
        Scanner scanner = new Scanner(System.in);
        int ops = 0;

        while (ops != 4) {   // Daily Planner menu options
            System.out.println("Options: ");
            System.out.println("1. Edit   2. Reset all   3. View   4. Exit");
            System.out.print("Enter your choice: ");
            ops = scanner.nextInt();

            switch (ops) {
                case 1:
                    dailyPlanner.edit();  // Calls the edit method from menu class
                    break;
                case 2:
                    dailyPlanner.reset();  // Calls the reset method from menu class
                    System.out.println("Time table is reset.");
                    break;
                case 3:
                    dailyPlanner.view();  // Calls the view method from menu class
                    break;
                case 4:
                    System.out.println("Exiting Daily Planner...");
                    break;
                default:
                    System.out.println("Invalid input!");
            }
        }
    }
}
