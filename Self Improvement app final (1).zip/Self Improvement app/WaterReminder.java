import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class WaterReminder {
    private double waterGoal;
    private double waterDrank;
    private int reminderInterval;

    public void start() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your daily water goal in liters: ");
        waterGoal = scanner.nextDouble();

        System.out.print("How often would you like to be reminded? (in minutes): ");
        reminderInterval = scanner.nextInt();

        waterDrank = 0;

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (waterDrank < waterGoal) {
                    System.out.println("\nReminder: Stay hydrated! You've drank " 
                            + waterDrank + " liters out of your " + waterGoal + " liter goal.");
                } else {
                    System.out.println("\nCongratulations! You've reached your daily water goal.");
                    timer.cancel();
                }
            }
        }, 0, reminderInterval * 60 * 1000);

        while (waterDrank < waterGoal) //Aman part revised here
        {
            System.out.print("\nEnter the amount of water you just drank (in liters): ");
            double waterInput = scanner.nextDouble(); //new variable added
        
            if (waterInput <= 0) {
                System.out.println("Please enter a valid positive amount of water.");
                continue; // Skip to the next iteration for invalid input
            }
        
            waterDrank += waterInput;
        
            if (waterDrank >= waterGoal) {
                System.out.println("Great job! You've achieved your daily water goal!");
                System.out.printf("You've exceeded your goal by %.2f liters.\n", waterDrank - waterGoal);
                timer.cancel();
                break;
            } else {
                System.out.printf("You've now drank %.2f liters out of your %.2f liter goal.\n", waterDrank, waterGoal);
            }
        }
    }
}