import java.util.Scanner;

public class WorkoutPlanner {

    // This method will be called from MainApp to execute the logic
    public static void executeFeature() {
        Scanner scanner = new Scanner(System.in);

        // Input height and weight
        System.out.print("Enter your height in cm: ");
        double heightCm = scanner.nextDouble();
        System.out.print("Enter your weight in kg: ");
        double weightKg = scanner.nextDouble();

        // Calculate BMI
        double bmi = calculateBMI(heightCm, weightKg);
        System.out.printf("Your BMI is: %.2f\n", bmi);

        // Determine fitness goal
        String fitnessGoal = determineFitnessGoal(bmi);
        System.out.println("Your fitness goal is: " + fitnessGoal);

        // Recommend a fitness program based on the goal
        suggestWorkoutProgram(fitnessGoal);
    }

    // Method to calculate BMI
    private static double calculateBMI(double heightCm, double weightKg) {
        double heightM = heightCm / 100; // Convert height to meters
        return weightKg / (heightM * heightM);
    }

    // Method to determine the fitness goal based on BMI
    private static String determineFitnessGoal(double bmi) {
        if (bmi < 18.5) {
            return "Gaining Muscle";
        } else if (bmi >= 25) {
            return "Losing Weight";
        } else {
            return "Maintaining Fitness";
        }
    }

    // Method to suggest workout program based on fitness goal
    private static void suggestWorkoutProgram(String fitnessGoal) {
        if (fitnessGoal.equals("Gaining Muscle")) {
            System.out.println("Here is your weight training program:");
            String[] weightWorkouts = {
                "Chest Press: 3 x 12",
                "Leg Press: 3 x 12",
                "Hack Squats: 3 x 12",
                "Shoulder Press: 3 x 12",
                "Bicep Curl: 3 x 12",
                "Tricep Pushdown: 3 x 12",
                "Lat Pulldown: 3 x 12",
                "Seated Row: 3 x 12",
                "Hamstring Curl: 3 x 12",
                "Calf Raise: 3 x 12",
                "Ab Machine: 3 x 15"
            };
            printWorkouts(weightWorkouts);
        } else if (fitnessGoal.equals("Losing Weight")) {
            System.out.println("Here is your cardio program:");
            String[] cardioWorkouts = {
                "Treadmill: 3 x 10 min",
                "Elliptical: 3 x 10 min",
                "Cycling: 3 x 15 min",
                "Rowing Machine: 3 x 10 min",
                "Stair Climber: 3 x 10 min",
                "Jump Rope: 3 x 2 min",
                "HIIT Circuit: 3 x 15 min",
                "Speed Walking: 3 x 15 min",
                "Aerobics: 3 x 20 min",
                "Swimming: 3 x 15 min"
            };
            printWorkouts(cardioWorkouts);
        } else if (fitnessGoal.equals("Maintaining Fitness")) {
            System.out.println("Here is your maintenance fitness program:");
            String[] maintainingFitnessWorkouts = {
                "Push-ups: 3 x 15",
                "Squats: 3 x 15",
                "Planks: 3 x 30 seconds",
                "Lunges: 3 x 12 per leg",
                "Jumping Jacks: 3 x 20",
                "Mountain Climbers: 3 x 20",
                "Burpees: 3 x 10",
                "Dumbbell Rows: 3 x 12",
                "Russian Twists: 3 x 20",
                "Bicycle Crunches: 3 x 20"
            };
            printWorkouts(maintainingFitnessWorkouts);
        } else {
            System.out.println("You are in a healthy BMI range. Keep maintaining your fitness!");
        }
    }

    // Method to print workouts
    private static void printWorkouts(String[] workouts) {
        for (String workout : workouts) {
            System.out.println(workout);
        }
    }
}
