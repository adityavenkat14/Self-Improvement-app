import java.util.Scanner;

class menu //Daily Planner
 {
    String[] day = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    String[][] time = new String[10][7];
    Scanner sa = new Scanner(System.in);

    public menu() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 7; j++) {
                time[i][j] = "   -";
            }
        }
    }

    public void reset() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 7; j++) {
                time[i][j] = "   -";
            }
        }
    }

    public void view() {
        System.out.print("Day  :               ");
        for (String i : day) {
            System.out.printf("%-20s", i);
        }
        System.out.println("\nTime :");
        int t = 6;

        for (int i = 0; i < 10; i++) {
            System.out.printf("%-2d:00 - %-2d:00        ", t, t + 2);
            for (int j = 0; j < 7; j++) {
                System.out.printf("%-20s", time[i][j]);
            }
            System.out.println();
            t++;
        }
    }

    public void timeSlot(int k, int d) {
        System.out.println("Add/Edit an activity");
        System.out.println("Currently: " + time[k][d]);
        time[k][d] = sa.next();
    }

    public void edit() {
        int count = 1;
        System.out.println("Which day do you want to edit?");
        for (String i : day) {
            System.out.println(count + ". " + i);
            count++;
        }
        int e = sa.nextInt();
        switch (e) {
            case 1:
                selectTimeSlot(0);
                break;
            case 2:
                selectTimeSlot(1);
                break;
            case 3:
                selectTimeSlot(2);
                break;
            case 4:
                selectTimeSlot(3);
                break;
            case 5:
                selectTimeSlot(4);
                break;
            case 6:
                selectTimeSlot(5);
                break;
            case 7:
                selectTimeSlot(6);
                break;
            default:
                break;
        }
    }

    private void selectTimeSlot(int dayIndex) {
        int count = 1;
        System.out.println("Select Time Slot: ");
        int t = 6;
        for (int i = 0; i < 10; i++) {
            System.out.printf(count + ". %-2d:00 - %-2d:00\n", t, t + 2);
            count++;
            t++;
        }
        int k = sa.nextInt();
        timeSlot(k - 1, dayIndex);
    }
}
