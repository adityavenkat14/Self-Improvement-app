import java.util.Random;
import java.util.Scanner;

public class BrainTrainer //Keshav's part
{

    public void start() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Brain Trainer!");
        System.out.println("Choose a game to play:");
        System.out.println("1. Equation Generator and Checker");
        System.out.println("2. Memory Game");
        System.out.print("Enter your choice (1 or 2): ");
        int choice = scanner.nextInt();

        if (choice == 1) {
            playEquationGame(scanner);
        } else if (choice == 2) {
            playMemoryGame(scanner);
        } else {
            System.out.println("Invalid choice. Exiting the Brain Trainer.");
        }
    }

    private void playEquationGame(Scanner scanner) {
        Random random = new Random();
        System.out.println("Welcome to the Equation Generator and Checker!");
        System.out.print("How many equations would you like to solve? ");
        int numEquations = scanner.nextInt();
        int correctCount = 0;

        for (int i = 0; i < numEquations; i++) {
            int num1 = random.nextInt(20) + 1;
            int num2 = random.nextInt(20) + 1;
            char operation = generateRandomOperation(random);
            int correctAnswer = calculateAnswer(num1, num2, operation);

            System.out.printf("Equation %d: %d %c %d = ?\n", i + 1, num1, operation, num2);
            System.out.print("Your answer: ");
            int userAnswer = scanner.nextInt();

            if (userAnswer == correctAnswer) {
                System.out.println("Correct!\n");
                correctCount++;
            } else {
                System.out.printf("Wrong! The correct answer is %d.\n\n", correctAnswer);
            }
        }

        System.out.printf("You answered %d out of %d equations correctly!\n", correctCount, numEquations);
    }

    private void playMemoryGame(Scanner scanner) {
        Random random = new Random();
        System.out.println("Welcome to the Memory Game!");
        System.out.print("How many numbers would you like to memorize? ");
        int numCount = scanner.nextInt();
        int[] numbers = new int[numCount];

        System.out.println("Memorize these numbers:");
        for (int i = 0; i < numCount; i++) {
            numbers[i] = random.nextInt(100);
            System.out.print(numbers[i] + " ");
        }
        System.out.println("\nPress Enter when you are ready.");
        scanner.nextLine();
        scanner.nextLine();

        System.out.println("Enter the numbers in the same order:");
        int correctCount = 0;
        for (int i = 0; i < numCount; i++) {
            System.out.printf("Number %d: ", i + 1);
            int userInput = scanner.nextInt();
            if (userInput == numbers[i]) {
                correctCount++;
            }
        }

        System.out.printf("You remembered %d out of %d numbers correctly!\n", correctCount, numCount);
    }

    private char generateRandomOperation(Random random) {
        char[] operations = {'+', '-', '*', '/'};
        return operations[random.nextInt(operations.length)];
    }

    private int calculateAnswer(int num1, int num2, char operation) {
        switch (operation) {
            case '+': return num1 + num2;
            case '-': return num1 - num2;
            case '*': return num1 * num2;
            case '/': return num2 != 0 ? num1 / num2 : 0;
            default: throw new IllegalArgumentException("Invalid operation: " + operation);
        }
    }
}